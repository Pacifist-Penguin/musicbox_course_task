const firebaseConfig = {
  apiKey: "AIzaSyA5rQaT6AFBffbM5Hhz1mk2bxyzIpBMefk",
  authDomain: "prototype-266a5.firebaseapp.com",
  projectId: "prototype-266a5",
  storageBucket: "prototype-266a5.appspot.com",
  messagingSenderId: "752480649033",
  appId: "1:752480649033:web:e229ea62be6ac0d8226498",
};

export {
    firebaseConfig
}